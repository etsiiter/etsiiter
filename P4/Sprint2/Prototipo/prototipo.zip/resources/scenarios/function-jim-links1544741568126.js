(function(window, undefined) {

  var jimLinks = {
    "0b2e3bb8-6006-4497-a6c8-a3cb4a061891" : {
      "Image_24" : [
        "2f9e8b20-8854-48d8-b51d-85ae50dae691"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "5ffe8c91-ccff-489a-a4a2-f067d14b2351"
      ],
      "Button_2" : [
        "2d091e80-2421-43f2-b22c-38822e0622b4"
      ],
      "Button_3" : [
        "7f084b5b-496b-4cbd-95df-099918269f3e"
      ]
    },
    "58030f68-0ce7-4bb2-8347-ad7b2ea73a19" : {
      "Image_24" : [
        "2f9e8b20-8854-48d8-b51d-85ae50dae691"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "5ffe8c91-ccff-489a-a4a2-f067d14b2351"
      ],
      "Menu_item_8" : [
        "df867296-d6bf-4252-a761-404c2e1cb1eb"
      ],
      "Button_2" : [
        "2d091e80-2421-43f2-b22c-38822e0622b4"
      ],
      "Rectangle_8" : [
        "aa97db67-81f4-4bff-ab55-f54fd81c580b"
      ]
    },
    "56033d56-5957-48de-b4fa-03be48410ad1" : {
      "Image_24" : [
        "2f9e8b20-8854-48d8-b51d-85ae50dae691"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "5ffe8c91-ccff-489a-a4a2-f067d14b2351"
      ],
      "Menu_item_6" : [
        "58030f68-0ce7-4bb2-8347-ad7b2ea73a19"
      ],
      "Menu_item_10" : [
        "0b2e3bb8-6006-4497-a6c8-a3cb4a061891"
      ],
      "Button_2" : [
        "2d091e80-2421-43f2-b22c-38822e0622b4"
      ],
      "Button_3" : [
        "aeb4c0db-581b-4f95-a27c-4b0b9fdb1365"
      ]
    },
    "7f084b5b-496b-4cbd-95df-099918269f3e" : {
      "Button_2" : [
        "2d091e80-2421-43f2-b22c-38822e0622b4"
      ]
    },
    "df867296-d6bf-4252-a761-404c2e1cb1eb" : {
      "Image_24" : [
        "2f9e8b20-8854-48d8-b51d-85ae50dae691"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "5ffe8c91-ccff-489a-a4a2-f067d14b2351"
      ],
      "Menu_item_6" : [
        "58030f68-0ce7-4bb2-8347-ad7b2ea73a19"
      ],
      "Menu_item_8" : [
        "df867296-d6bf-4252-a761-404c2e1cb1eb"
      ],
      "Menu_item_10" : [
        "0b2e3bb8-6006-4497-a6c8-a3cb4a061891"
      ],
      "Button_2" : [
        "2d091e80-2421-43f2-b22c-38822e0622b4"
      ]
    },
    "aa97db67-81f4-4bff-ab55-f54fd81c580b" : {
      "Image_24" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "26a1a298-625d-4d16-a0dc-63c98d34e07d" : {
    },
    "2f9e8b20-8854-48d8-b51d-85ae50dae691" : {
      "Image_24" : [
        "2f9e8b20-8854-48d8-b51d-85ae50dae691"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "5ffe8c91-ccff-489a-a4a2-f067d14b2351"
      ],
      "Menu_item_6" : [
        "58030f68-0ce7-4bb2-8347-ad7b2ea73a19"
      ],
      "Menu_item_8" : [
        "df867296-d6bf-4252-a761-404c2e1cb1eb"
      ],
      "Menu_item_10" : [
        "0b2e3bb8-6006-4497-a6c8-a3cb4a061891"
      ]
    },
    "5ffe8c91-ccff-489a-a4a2-f067d14b2351" : {
      "Image_24" : [
        "2f9e8b20-8854-48d8-b51d-85ae50dae691"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "5ffe8c91-ccff-489a-a4a2-f067d14b2351"
      ],
      "Menu_item_8" : [
        "df867296-d6bf-4252-a761-404c2e1cb1eb"
      ],
      "Button_2" : [
        "2d091e80-2421-43f2-b22c-38822e0622b4"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Rectangle_7" : [
        "2f9e8b20-8854-48d8-b51d-85ae50dae691"
      ],
      "Rectangle_8" : [
        "aa97db67-81f4-4bff-ab55-f54fd81c580b"
      ],
      "Image_24" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "aeb4c0db-581b-4f95-a27c-4b0b9fdb1365" : {
      "Image_24" : [
        "2f9e8b20-8854-48d8-b51d-85ae50dae691"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "5ffe8c91-ccff-489a-a4a2-f067d14b2351"
      ],
      "Menu_item_8" : [
        "df867296-d6bf-4252-a761-404c2e1cb1eb"
      ],
      "Button_2" : [
        "2d091e80-2421-43f2-b22c-38822e0622b4"
      ]
    },
    "2d091e80-2421-43f2-b22c-38822e0622b4" : {
      "Image_24" : [
        "2f9e8b20-8854-48d8-b51d-85ae50dae691"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "5ffe8c91-ccff-489a-a4a2-f067d14b2351"
      ],
      "Menu_item_8" : [
        "df867296-d6bf-4252-a761-404c2e1cb1eb"
      ],
      "Button_2" : [
        "60c4df0c-95a3-46a0-bb47-5a3e2a8369ca"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);