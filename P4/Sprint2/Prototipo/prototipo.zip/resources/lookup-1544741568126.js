(function(window, undefined) {
  var dictionary = {
    "0b2e3bb8-6006-4497-a6c8-a3cb4a061891": "Apuntes",
    "58030f68-0ce7-4bb2-8347-ad7b2ea73a19": "Proyecto",
    "56033d56-5957-48de-b4fa-03be48410ad1": "Proyectos",
    "7f084b5b-496b-4cbd-95df-099918269f3e": "subir_apuntes",
    "df867296-d6bf-4252-a761-404c2e1cb1eb": "Archivos",
    "aa97db67-81f4-4bff-ab55-f54fd81c580b": "Registrarse",
    "26a1a298-625d-4d16-a0dc-63c98d34e07d": "Crear grupos 2",
    "2f9e8b20-8854-48d8-b51d-85ae50dae691": "Feed",
    "5ffe8c91-ccff-489a-a4a2-f067d14b2351": "Cambiar Usuario",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Loguearse",
    "aeb4c0db-581b-4f95-a27c-4b0b9fdb1365": "Crear Proyecto",
    "60c4df0c-95a3-46a0-bb47-5a3e2a8369ca": "Crear grupos",
    "2d091e80-2421-43f2-b22c-38822e0622b4": "Chat",
    "e73b655d-d3ec-4dcc-a55c-6e0293422bde": "960 grid - 16 columns",
    "ef07b413-721c-418e-81b1-33a7ed533245": "960 grid - 12 columns",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);