(function(window, undefined) {

  var jimLinks = {
    "df867296-d6bf-4252-a761-404c2e1cb1eb" : {
      "Image_24" : [
        "2f9e8b20-8854-48d8-b51d-85ae50dae691"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "5ffe8c91-ccff-489a-a4a2-f067d14b2351"
      ]
    },
    "aa97db67-81f4-4bff-ab55-f54fd81c580b" : {
      "Image_24" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Rectangle_7" : [
        "2f9e8b20-8854-48d8-b51d-85ae50dae691"
      ],
      "Rectangle_8" : [
        "aa97db67-81f4-4bff-ab55-f54fd81c580b"
      ],
      "Image_24" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "5ffe8c91-ccff-489a-a4a2-f067d14b2351" : {
      "Image_24" : [
        "2f9e8b20-8854-48d8-b51d-85ae50dae691"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "5ffe8c91-ccff-489a-a4a2-f067d14b2351"
      ],
      "Menu_item_8" : [
        "df867296-d6bf-4252-a761-404c2e1cb1eb"
      ]
    },
    "2f9e8b20-8854-48d8-b51d-85ae50dae691" : {
      "Image_24" : [
        "2f9e8b20-8854-48d8-b51d-85ae50dae691"
      ],
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "5ffe8c91-ccff-489a-a4a2-f067d14b2351"
      ],
      "Menu_item_8" : [
        "df867296-d6bf-4252-a761-404c2e1cb1eb"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);