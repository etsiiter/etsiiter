function initData() {
  jimData.variables["asasd"] = "";
  jimData.isInitialized = true;
}